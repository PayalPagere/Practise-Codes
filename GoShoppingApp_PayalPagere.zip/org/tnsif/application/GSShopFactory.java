package org.tnsif.application;

import org.tnsif.application.GSNormalAcc;
import org.tnsif.application.GSPrimeAcc;
import org.tnsif.framework.NormalAcc;
import org.tnsif.framework.PrimeAccount;
import org.tnsif.framework.ShopFactory;

public class GSShopFactory extends ShopFactory{

	@Override
	public PrimeAccount getNewPrimeAcc(int accno, String accname, float charges, boolean isPrime) {
		GSPrimeAcc n=new GSPrimeAcc(accno,accname,charges,isPrime);
		return n;
	}

	
	@Override
	public NormalAcc getNewNormalAcc(int accno, String accname, float charges, float deliveryCharges) {
		GSNormalAcc m=new GSNormalAcc(accno,accname,charges,deliveryCharges);
		return m;
	}
	
}
