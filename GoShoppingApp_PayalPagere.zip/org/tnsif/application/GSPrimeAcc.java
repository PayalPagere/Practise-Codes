package org.tnsif.application;

import org.tnsif.framework.PrimeAccount;

public class GSPrimeAcc extends PrimeAccount{

	public GSPrimeAcc(int accno, String accname, float charges, boolean isPrime) {
		super(accno, accname, charges, isPrime);
		
	}

	@Override
	public String toString() {
		return "GSPrimeAcc [toString()=" + super.toString() + "]";
	}
	

}
