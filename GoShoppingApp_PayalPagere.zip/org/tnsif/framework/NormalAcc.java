package org.tnsif.framework;

public abstract class NormalAcc extends ShopAccount{

	final private float deliveryCharges;

	public NormalAcc(int accno, String accname, float charges,float deliveryCharges) {
		super(accno, accname, charges);
		this.deliveryCharges=deliveryCharges;
		// TODO Auto-generated constructor stub
	}
	//toString
	@Override
	public String toString() {
		return "NormalAcc [deliveryCharges=" + deliveryCharges + "]";
	}
	public void bookProduct(float charges)
	{
		System.out.println("Acc no:"+this.getAccno()+ " "+"Acc name:"+this.getAccname()+" "+"Delivery charges: "+(this.getCharges()+this.deliveryCharges));
	}
	
}
