package org.tnsif.framework;

public abstract class ShopAccount {
	//private data members
	private int accno;
	private String accname;
	private float charges;
	
	//getters and setters
	public int getAccno() {
		return accno;
	}
	public void setAccno(int accno) {
		this.accno = accno;
	}
	public String getAccname() {
		return accname;
	}
	public void setAccname(String accname) {
		this.accname = accname;
	}
	public float getCharges() {
		return charges;
	}
	public void setCharges(float charges) {
		this.charges = charges;
	}
	//Parameterized Constructor
	public ShopAccount(int accno, String accname, float charges) {
		super();
		this.accno = accno;
		this.accname = accname;
		this.charges = charges;
	}
	//to string method
	@Override
	public String toString() {
		return "ShopAccount [accno=" + accno + ", accname=" + accname + ", charges=" + charges + "]";
	}
	
	abstract void bookProduct(float charges);
	public void items(float charges)
	{
		System.out.println(charges);	
	}
	
}
