package org.tnsif.framework;

public abstract class PrimeAccount extends ShopAccount{
	//Private data types
	private boolean isPrime;
	private static final float deliveryCharges=0.0f; 
	
	//constructor
	public PrimeAccount(int accno, String accname, float charges, boolean isPrime) {
		super(accno, accname, charges);
		this.isPrime=isPrime;
		
	}
	public void bookProduct(float charges)
	{
		System.out.println("Acc no."+this.getAccno()+ " "+"Acc name"+this.getAccname()+" "+"Delivery charges"+this.getCharges()+" "+"Charges"+this.deliveryCharges);
	}
	//to string
	@Override
	public String toString() {
		return "PrimeAccount [isPrime=" + isPrime + "]";
	}
	
}
