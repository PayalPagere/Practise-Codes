package org.tnsif.framework;

public abstract class ShopFactory {
	public abstract PrimeAccount getNewPrimeAcc(int accno,String accname,float charges,boolean isPrime);
	public abstract NormalAcc getNewNormalAcc(int accno,String accname,float charges,float deliveryCharges);
}
